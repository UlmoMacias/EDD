package Tetris.Logica.Figuras;

import Tetris.utils.Punto2D;
import java.awt.Color;

public interface Figura{

    public Punto2D[] translate(Punto2D dxy);
    public Punto2D[] getPuntos();
    public void rotateRigth();
    public void rotateLeft();
    public Color getFillColor();
    public Color getBorderColor();
    public void restablece();

}
