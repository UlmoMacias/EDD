package Tetris.utils;

public class Punto2D {

    public Punto2D(){

    }
    
    public Punto2D(int x,int y){

    }

    public int getX() {
        return 0;
    }

    public void setX(int x) {
    }

    public int getY() {
        return 0;
    }

    public void setY(int y) {
    }

    @Override
    public boolean equals(Object obj){
        return true;
    }

    public void move(int dx,int dy){
    }

    public Punto2D translate(int dx,int dy){
        return null;
    }

    @Override
    public Punto2D clone(){
        return null;
    }
}
